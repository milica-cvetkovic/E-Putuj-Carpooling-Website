<div class="back-image-message">
   <div class="container-fluid">
      <div class="row">
         <div class="col-sm-4 back-image-inbox">
            <ul style="color:black;">
               <li>
                  <div class="container-fluid" style="margin: 2em;">
                     <div><b>mixy</b></div>
                     <a href="inbox_privatnik_poruka1.html">
                        <div class="hoverable-cells div-messages" style="padding-left: 15px;">
                           Mesto polaska: Beograd;...
                        </div>
                     </a>
                  </div>
               </li>
               <hr style="height:1px; border:none; color:#333; background-color:#333;">
               <li>
                  <div class="container-fluid" style="margin: 2em;">
                     <div><b>zeljko.urosevic</b></div>
                     <a href="inbox_privatnik_poruka1.html">
                        <div class="hoverable-cells div-messages" style="padding-left: 15px;">
                           Mesto polaska: Požarevac;...
                        </div>
                     </a>
                  </div>
               </li>
               <hr style="height:1px; border:none; color:#333; background-color:#333;">
               <li>
                  <div class="container-fluid" style="margin: 2em;">
                     <div><b>peka</b></div>
                     <a href="inbox_privatnik_poruka1.html">
                        <div class="hoverable-cells div-messages" style="padding-left: 15px;">
                           Mesto polaska: Velika Plana;...
                        </div>
                     </a>
                  </div>
               </li>
               <hr style="height:1px; border:none; color:#333; background-color:#333;">
               <li>
                  <div class="container-fluid" style="margin: 2em;">
                     <div><b>mika</b></div>
                     <a href="inbox_privatnik_poruka1.html">
                        <div class="hoverable-cells div-messages" style="padding-left: 15px;">
                           Mesto polaska: Trebinje;...
                        </div>
                     </a>
                  </div>
               </li>
               <hr style="height:1px; border:none; color:#333; background-color:#333;">
               <li>
                  <div class="container-fluid" style="margin: 2em;">
                     <div><b>zika</b></div>
                     <a href="inbox_privatnik_poruka1.html">
                        <div class="hoverable-cells div-messages" style="padding-left: 15px;">
                           Mesto polaska: Prag;...
                        </div>
                     </a>
                  </div>
               </li>
            </ul>
         </div>
         <div class="col-sm-8 justify-content-center back-image-message">
            <div class="container-fluid">
               <table class="table" style="color: black; border-width: 2px; text-align: center;">
                  <tr>
                     <td>Mesto polaska</td>
                     <td>Beograd</td>
                  </tr>
                  <tr>
                     <td>Mesto dolaska</td>
                     <td>Budimpešta</td>
                  </tr>
                  <tr>
                     <td>Datum polaska od</td>
                     <td>24/7/2023</td>
                  </tr>
                  <tr>
                     <td>Datum polaska do</td>
                     <td></td>
                  </tr>
                  <tr>
                     <td>Vreme polaska od</td>
                     <td>18:00</td>
                  </tr>
                  <tr>
                     <td>Vreme polaska do</td>
                     <td></td>
                  </tr>
                  <tr>
                     <td>Prevozno sredstvo</td>
                     <td>Automobil</td>
                  </tr>
                  <tr>
                     <td>Cena od</td>
                     <td>20€</td>
                  </tr>
                  <tr>
                     <td>Cena do</td>
                     <td>40€</td>
                  </tr>
                  <tr>
                     <td>Broj putnika</td>
                     <td>1</td>
                  </tr>
               </table>
               <div class="container-fluid">
                  <a href="napraviPonudu.html"><button type="button" class="btn make-offer-btn" style="position: relative; left: 50%;">Napravi
                        ponudu</button></a>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>